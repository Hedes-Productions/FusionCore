                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2957550
Corner Brackets For System20 2020 / 2040 Extrusion by mce076 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

These are corner brackets designed to suit System 2020 (2020/2040) extrusion.

They can be used to build or strengthen/reinforce 3D printer frames and to assist in vibration isolation of vertical frame components such as the Z axis extrusions. There are both 2020 and 2040 compatible versions, some with sliding mounts and others in different styles with either double or single sided supports. All brackets have 4mm thick walls and screw holes have been recessed to lower the profile of the required socket head screws.

In order to mount the brackets you will need the appropriate amount of these:

- M4x6mm socket head screws
- M4 V-slot nuts

If you would like a style or size added please comment and let me know so i can add to the collection. I would also love to see what you're using them on :)

2018-07-10 - M3 versions added to the files list in a zip file

2018-10-25 - M5 versions added in a zip file

2019-03-26 - Misc brackets (3 sided corners and L shapes in M3/M4/M5) added in zip file


# Print Settings

Printer Brand: Creality
Printer: CR-10S
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 20%-100%